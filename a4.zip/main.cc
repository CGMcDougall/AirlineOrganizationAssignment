#include <iostream>
#include "Control.h"

using namespace std;

int main(){
	
	Control control;
	control.launch();
	
	return 0;

}
